// variable for our program to determine if a guest can ride the rollercoaster
var minimum_age = 10;
var minumum_height = 42;