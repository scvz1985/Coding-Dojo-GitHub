// This variable would be adding up the times you hit like to sum up the times you gotten up for water
var likeCOunt = 0;
// Keeping tab of the times you've gotten up to get a sip of water by adding likes
function increaseLikes () {
    // Tally of times by adding up all likes
    likeCOunt = likeCOunt + 1;
}
