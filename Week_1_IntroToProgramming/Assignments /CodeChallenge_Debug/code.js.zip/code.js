function greeting (){
    return "Hello World";
}
var word = greeting();
console.log(word);

//To me it appears as console.log needs more direction. I was able to print Hello World by typing in "word" in the ()