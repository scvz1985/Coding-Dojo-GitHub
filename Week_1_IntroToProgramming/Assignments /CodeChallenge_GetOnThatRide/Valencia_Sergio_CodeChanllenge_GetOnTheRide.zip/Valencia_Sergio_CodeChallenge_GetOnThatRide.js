//First I want to identify all that I am trying to do. Check riders age and check for their age.
var height = 56;
var age = 22;
//Variables are going to be either the min height of 42. If we were to only check for the height all we need to do is remove the && 
if (height >= 42 && age >= 10)
console.log("Get on that ride, kiddo!")
else {
console.log("Sorry kiddo, maybe next year");
}